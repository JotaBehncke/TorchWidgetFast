package com.bejota.torchwidget
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
object TorchController {
    private var cameraId: String? = null
    private fun findCameraId(cm: CameraManager): String? {
        cameraId?.let { return it }
        for (id in cm.cameraIdList) {
            val chars = cm.getCameraCharacteristics(id)
            val hasFlash = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            val facing = chars.get(CameraCharacteristics.LENS_FACING)
            if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) { cameraId = id; return id }
        }
        for (id in cm.cameraIdList) {
            val chars = cm.getCameraCharacteristics(id)
            if (chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true) { cameraId = id; return id }
        }
        return null
    }
    fun setTorch(context: Context, on: Boolean): Boolean {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = findCameraId(cm) ?: return false
        return try { cm.setTorchMode(id, on); true } catch (e: Exception) { false }
    }
}
