package com.bejota.torchwidget
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
class TorchWidgetConfigActivity : AppCompatActivity() {
    private var appWidgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_config); setResult(RESULT_CANCELED)
        appWidgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        val grey = findViewById<SeekBar>(R.id.seekGrey)
        val alpha = findViewById<SeekBar>(R.id.seekAlpha)
        val preview = findViewById<TextView>(R.id.preview)
        val btn = findViewById<Button>(R.id.btnApply)
        grey.max = 255; alpha.max = 255
        fun upd(){ preview.setBackgroundColor(Prefs.colorFromGrey(grey.progress)); preview.alpha = alpha.progress/255f }
        grey.progress = Prefs.getBgGrey(this, appWidgetId); alpha.progress = Prefs.getBgAlpha(this, appWidgetId); upd()
        val l = object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) = upd()
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        }
        grey.setOnSeekBarChangeListener(l); alpha.setOnSeekBarChangeListener(l)
        btn.setOnClickListener {
            Prefs.setBgGrey(this, appWidgetId, grey.progress); Prefs.setBgAlpha(this, appWidgetId, alpha.progress)
            val mgr = AppWidgetManager.getInstance(this); TorchWidgetProvider().updateAppWidget(this, mgr, appWidgetId)
            val result = Intent().apply { putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId) }
            setResult(RESULT_OK, result); finish()
        }
    }
}
