package com.bejota.torchwidget
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.RemoteViews
class TorchWidgetProvider : AppWidgetProvider() {
    companion object { private const val ACTION_TOGGLE = "com.bejota.torchwidget.TOGGLE" }
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) updateAppWidget(context, appWidgetManager, id)
    }
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val on = !Prefs.getState(context)
            if (TorchController.setTorch(context, on)) {
                Prefs.setState(context, on); vibrate(context)
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, TorchWidgetProvider::class.java))
                for (id in ids) updateAppWidget(context, mgr, id)
            }
        }
    }
    private fun vibrate(context: Context) {
        try {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) v.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(15)
        } catch (_: Exception) {}
    }
    private fun getTogglePI(c: Context): PendingIntent {
        val i = Intent(c, TorchWidgetProvider::class.java).apply { action = ACTION_TOGGLE }
        return PendingIntent.getBroadcast(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val v = RemoteViews(context.packageName, R.layout.widget_torch)
        val on = Prefs.getState(context)
        v.setImageViewResource(R.id.iconView, if (on) R.drawable.ic_flashlight_on else R.drawable.ic_flashlight_off)
        val g = Prefs.getBgGrey(context, appWidgetId).coerceIn(0,255)
        val a = Prefs.getBgAlpha(context, appWidgetId).coerceIn(0,255)
        v.setInt(R.id.bgView, "setColorFilter", Prefs.colorFromGrey(g))
        v.setInt(R.id.bgView, "setAlpha", a)
        v.setOnClickPendingIntent(R.id.root, getTogglePI(context))
        appWidgetManager.updateAppWidget(appWidgetId, v)
    }
}
