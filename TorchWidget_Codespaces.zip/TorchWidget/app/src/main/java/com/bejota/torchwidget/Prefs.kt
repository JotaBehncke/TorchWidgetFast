package com.bejota.torchwidget
import android.content.Context
import android.graphics.Color
object Prefs {
    private const val PREFS = "torch_prefs"
    fun setState(ctx: Context, on: Boolean) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("on", on).apply() }
    fun getState(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("on", false)
    fun setBgGrey(ctx: Context, id: Int, g: Int) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("grey_$id", g).apply() }
    fun getBgGrey(ctx: Context, id: Int): Int = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("grey_$id", 128)
    fun setBgAlpha(ctx: Context, id: Int, a: Int) { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("alpha_$id", a).apply() }
    fun getBgAlpha(ctx: Context, id: Int): Int = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("alpha_$id", 200)
    fun colorFromGrey(g: Int): Int = Color.rgb(g,g,g)
}
