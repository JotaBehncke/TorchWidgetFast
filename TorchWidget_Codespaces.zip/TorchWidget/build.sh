#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null
apt-get install -y wget unzip curl git ca-certificates gradle >/dev/null
export ANDROID_SDK_ROOT="$PWD/.android-sdk"
export ANDROID_HOME="$ANDROID_SDK_ROOT"
export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:$PATH"
mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
if [ ! -d "$ANDROID_SDK_ROOT/cmdline-tools/latest" ]; then
  echo "[*] Downloading Android cmdline-tools..."
  cd "$ANDROID_SDK_ROOT/cmdline-tools"
  wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdtools.zip
  unzip -q cmdtools.zip -d latest
  rm -f cmdtools.zip
  cd - >/dev/null
fi
yes | sdkmanager --licenses >/dev/null || true
echo "[*] Installing SDK packages..."
yes | sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" >/dev/null
echo "[*] Building release APK..."
gradle --no-daemon clean assembleRelease
echo "[✔] Done. APK at: app/build/outputs/apk/release/app-release.apk"
